#ifndef MAIN_DLL_H
#define MAIN_DLL_H

#include "main_dll_global.h"

class MAIN_DLLSHARED_EXPORT Main_dll
{

public:
    Main_dll();
    int add(int a, int b);

};

#endif // MAIN_DLL_H
