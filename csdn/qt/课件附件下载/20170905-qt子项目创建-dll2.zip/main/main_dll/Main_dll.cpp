#include "Main_dll.h"


Main_dll::Main_dll()
{
}

int Main_dll::add(int a, int b)
{
    return a + b;

}
