#ifndef MAIN_DLL_GLOBAL_H
#define MAIN_DLL_GLOBAL_H

#include <QtCore/qglobal.h>

#if defined(MAIN_DLL_LIBRARY)
#  define MAIN_DLLSHARED_EXPORT Q_DECL_EXPORT
#else
#  define MAIN_DLLSHARED_EXPORT Q_DECL_IMPORT
#endif

#endif // MAIN_DLL_GLOBAL_H
