#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDebug>

#include "Main_dll.h"


MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    Main_dll a;
    qDebug() << a.add(4,5);
}

MainWindow::~MainWindow()
{
    delete ui;
}
