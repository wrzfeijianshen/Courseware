#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "Aaa_dll.h"
#include "Aaa_lib.h"

#include <QDebug>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    Aaa_dll a;
    int c = a.add(3,5);
qDebug() <<"\n" << c;
    Aaa_lib b;
    int d = b.add100(1,2);
    qDebug() <<"\n" << d;

}

MainWindow::~MainWindow()
{
    delete ui;
}
