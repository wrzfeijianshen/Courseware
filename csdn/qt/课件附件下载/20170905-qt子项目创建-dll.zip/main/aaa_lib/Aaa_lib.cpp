#include "Aaa_lib.h"


Aaa_lib::Aaa_lib()
{
}

int Aaa_lib::add100(int a, int b)
{
    return a + b + 300;
}
