#ifndef AAA_LIB_H
#define AAA_LIB_H


class Aaa_lib
{

public:
    Aaa_lib();
    int add100(int a,int b);
};

#endif // AAA_LIB_H
