#include "Aaa_dll.h"


Aaa_dll::Aaa_dll()
{
}

int Aaa_dll::add(int a, int b)
{
    return a + b +10;
}
