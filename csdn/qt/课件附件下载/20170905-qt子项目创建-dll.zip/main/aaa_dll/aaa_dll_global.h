#ifndef AAA_DLL_GLOBAL_H
#define AAA_DLL_GLOBAL_H

#include <QtCore/qglobal.h>

#if defined(AAA_DLL_LIBRARY)
#  define AAA_DLLSHARED_EXPORT Q_DECL_EXPORT
#else
#  define AAA_DLLSHARED_EXPORT Q_DECL_IMPORT
#endif

#endif // AAA_DLL_GLOBAL_H
