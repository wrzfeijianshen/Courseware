#ifndef AAA_DLL_H
#define AAA_DLL_H

#include "aaa_dll_global.h"

class AAA_DLLSHARED_EXPORT Aaa_dll
{

public:
    Aaa_dll();
    int add(int a,int b);
};

#endif // AAA_DLL_H
